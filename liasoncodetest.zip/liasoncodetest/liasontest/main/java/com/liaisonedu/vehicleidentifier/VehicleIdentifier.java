package com.liaisonedu.vehicleidentifier;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import java.io.*;
import java.util.*;
import org.jdom2.*;
import org.jdom2.input.SAXBuilder;
import org.w3c.dom.NodeList;
import org.xml.sax.*;

import com.sun.org.apache.xerces.internal.dom.DeferredDocumentImpl;

//import org.apache.commons.io.IOUtils;

/**
 * Hello world!
 * 
 */
public class VehicleIdentifier {

	public static void main(String[] args) {

		VehicleIdentifier obj = new VehicleIdentifier();
		String fileContent = obj.getFile("xml/vehicles.xml");

	}

	private String getFile(String fileName) {

		StringBuilder result = new StringBuilder("");

		// Get file from resources folder
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(fileName).getFile());

		// parse xml
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			com.sun.org.apache.xerces.internal.dom.DeferredDocumentImpl doc = (DeferredDocumentImpl) dBuilder
					.parse(file);
			NodeList nList = doc.getElementsByTagName("vehicle");
			reportVehicleType(nList);

		} catch (ParserConfigurationException e1) {
			e1.printStackTrace();
		} catch (SAXException e2) {
			e2.printStackTrace();
		} catch (IOException e3) {
			e3.printStackTrace();
		}

		return result.toString();

	}

	private void reportVehicleType(NodeList nList) {
		for (int j = 0; j < nList.getLength(); j++) {
			NodeList nChildren = nList.item(j).getChildNodes();
			String vehicleName = "";
			String material = "";
			String vehicleType = "";
			for (int i = 0; i < nChildren.getLength(); i++) {
				boolean isCar = true;
				if ("id".equals(nChildren.item(i).getNodeName())) {
					vehicleName = nChildren.item(i).getTextContent();
				}

				if ("frame".equals(nChildren.item(i).getNodeName())) {
					NodeList materials = nChildren.item(i).getChildNodes();
					System.out.println("Out of " + nList.getLength() + " vehicles, vehicle #" + j + " named "
							+ vehicleName + " is made of " + materials.item(1).getTextContent());
					if ("wood".equals(materials.item(1).getTextContent())) {
						vehicleType = "toy ";
					}

				}

				if ("wheels".equals(nChildren.item(i).getNodeName())) {
					NodeList wheels = nChildren.item(i).getChildNodes();
					int weelPairsCount = 0;
					for (int k = 1; k < wheels.getLength(); k++) {
						NodeList wheelTypes = wheels.item(k).getChildNodes();

						for (int l = 1; l < wheelTypes.getLength(); l++) {
							isCar = (wheelTypes.item(l).getTextContent() != null)
									&& "position".equals(wheelTypes.item(l).getNodeName())
									&& (wheelTypes.item(l).getTextContent().indexOf("left") > -1
											|| wheelTypes.item(l).getTextContent().indexOf("right") > -1);

							if (isCar)
								weelPairsCount++;
						}
					}
					if (weelPairsCount > 0) {
						vehicleType += " car";
					} else {
						vehicleType += " bicycle";
					}
					// report vehicle type
					System.out.println("Vehicle " + vehicleName + " is a " + vehicleType + "\n");
				}
			}
		}
	}

}
