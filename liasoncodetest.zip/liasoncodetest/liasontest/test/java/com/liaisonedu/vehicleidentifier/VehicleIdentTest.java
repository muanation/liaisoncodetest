package com.liaisonedu.vehicleidentifier;

import static org.junit.Assert.*;

import org.junit.Test;

public class VehicleIdentTest {

	@Test
	public void testMain() {
		assertTrue(true);
	}

	public void assertTrue(boolean ass) {
		VehicleIdentifier.main(null);
	}

}
